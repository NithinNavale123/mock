package com.jsp.jese8.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.jsp.jese8.dto.StudentDto;


@Component
public class StudentDao {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("zxc");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();
	
	
	public void insert(StudentDto dto) {
		entityTransaction.begin();
		entityManager.persist(dto);
		entityTransaction.commit();
	}
	
	public void delete(int Std_id) {
		StudentDto s = entityManager.find(StudentDto.class, Std_id);

		entityTransaction.begin();
		entityManager.remove(s);
		entityTransaction.commit();

	}
	public List<StudentDto> fetchall() {
		Query query = entityManager.createQuery("select data from StudentDto data");
		List<StudentDto> dtos = query.getResultList();
		return dtos;
	}
	
	
	public void update(int Std_id, String Std_name,int Std_marks, int Std_phno) {
		StudentDto dto = entityManager.find(StudentDto.class, Std_id);
		dto.setStd_id(Std_id);
		dto.setStd_name(Std_name);
		dto.setStd_marks(Std_name);
		dto.setStd_phno(Std_phno);

		entityTransaction.begin();
		entityManager.merge(dto);
		entityTransaction.commit();
	}
	

	public StudentDto fetch(int std_id) {
		StudentDto dto = entityManager.find(StudentDto.class, std_id);
		return dto;
	}


	
}
