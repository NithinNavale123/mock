package com.jsp.jese8.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.jese8.dao.StudentDao;
import com.jsp.jese8.dto.StudentDto;

@Controller
public class StudentController {
	@Autowired
	StudentDto dto;

	@Autowired
	StudentDao dao;
	@RequestMapping("/signup")
	public ModelAndView Demo() {
		ModelAndView andView = new ModelAndView("insert.jsp");
		andView.addObject("ins", dto);
		return andView;
	}

	@ResponseBody
	@RequestMapping("/insert")
	public void insert(StudentDto dto) {
		dao.insert(dto);
	}
	@RequestMapping("/def")
	public ModelAndView Demo3() {
		ModelAndView andView = new ModelAndView("delete.jsp");
		andView.addObject("del", dto);
		return andView;
	}

	@ResponseBody
	@RequestMapping("/delete")
	public void delete(int Std_id) {
		dao.delete(Std_id);
	}
	@RequestMapping("/fetchall")
	@ResponseBody
	public ModelAndView fetchall() {
		List<StudentDto> dtos = dao.fetchall();
		ModelAndView andView = new ModelAndView("fetchall.jsp");
		andView.addObject("fth", dtos);
		return andView;
	}
	
	@RequestMapping("/update")
	public ModelAndView Demo1() {
		ModelAndView Veiw = new ModelAndView("update.jsp");
		Veiw.addObject("up", dto);
		return Veiw;
	}
	@ResponseBody
	@RequestMapping("/update1")
	public void fetch(int Std_id, String Std_name,int Std_marks, int Std_phno) {
		dao.update(Std_id, Std_name, Std_marks, Std_phno);

	}
	

	@RequestMapping("/fetch")
	public ModelAndView fetch() {
		ModelAndView andView = new ModelAndView("fetch.jsp");
		andView.addObject("ft", dto);
		return andView;
	}
    @ResponseBody
	@RequestMapping("/fetch1")
	public ModelAndView display(int Std_id) {
		StudentDto empDto2 = dao.fetch(Std_id);
		ModelAndView andView = new ModelAndView("display.jsp");
		andView.addObject("ft1", empDto2);
		return andView;
	}
}
