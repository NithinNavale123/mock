package com.jsp.jese8.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class StudentDto {
	@Id
	private int Std_id;
	private String Std_name;
	private String Std_marks;
	private int Std_phno;

	public int getStd_id() {
		return Std_id;
	}

	public void setStd_id(int std_id) {
		Std_id = std_id;
	}

	public String getStd_name() {
		return Std_name;
	}

	public void setStd_name(String std_name) {
		Std_name = std_name;
	}

	public String getStd_marks() {
		return Std_marks;
	}

	public void setStd_marks(String std_marks) {
		Std_marks = std_marks;
	}

	public int getStd_phno() {
		return Std_phno;
	}

	public void setStd_phno(int std_phno) {
		Std_phno = std_phno;
	}
}
